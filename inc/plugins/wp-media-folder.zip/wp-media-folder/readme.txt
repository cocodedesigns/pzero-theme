=== Media test ===
Tags: media, folder
Requires at least: 3.5.1
Tested up to: 4.2.2
Stable tag: 3.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP media Folder is a WordPress plugin that enhance the WordPress media manager by adding a folder manager inside.

== Description ==

WP media Folder is a WordPress plugin that enhance the WordPress media manager by adding a folder manager inside.

